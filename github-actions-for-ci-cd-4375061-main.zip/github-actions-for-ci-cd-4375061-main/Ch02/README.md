# 2. Continuous Integration Workflows
- [02_02_use_starter_workflows_in_github_actions](./02_02_use_starter_workflows_in_github_actions/README.md)
- [02_03_ci_for_javascript](./02_03_ci_for_javascript/README.md)
- [02_04_ci_for_python](./02_04_ci_for_python/README.md)
- [02_05_ci_for_go](./02_05_ci_for_go/README.md)
- [02_06_challenge_develop_a_ci_pipeline](./02_06_challenge_develop_a_ci_pipeline/README.md)
- [02_07_solution_develop_a_ci_pipeline](./02_07_solution_develop_a_ci_pipeline/README.md)
